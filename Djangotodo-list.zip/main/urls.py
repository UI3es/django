from django.conf.urls import url
from django.contrib import admin
from main import views
from django.urls import path, include

"""
URLs
Okay, now let's wire up the API URLs. On to tutorial/urls.py...

Because we're using viewsets instead of views, we can automatically generate the URL conf for our API, by simply registering the viewsets with a router class.

Again, if we need more control over the API URLs we can simply drop down to using regular class-based views, and writing the URL conf explicitly.

Finally, we're including default login and logout views for use with the browsable API. That's optional, but useful if your API requires authentication and you want to use the browsable API.
"""
from rest_framework import routers


router = routers.DefaultRouter()
router.register(r'api-auth/users', views.UserViewSet)
router.register(r'api-auth/groups', views.GroupViewSet)

urlpatterns = [
  url(r'^admin/', admin.site.urls),
  url(r'^$', views.home, name='home'),
  path('add_todo/', views.add_todo),
  path('delete_todo/<int:todo_id>/', views.delete_todo),

  path('', include(router.urls)),
  path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
