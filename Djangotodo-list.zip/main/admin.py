from django.contrib import admin
from . import models


class TodoAdmin(admin.ModelAdmin):
    list_display = ("added_date",  "text")

admin.site.register(models.Todo, TodoAdmin)
